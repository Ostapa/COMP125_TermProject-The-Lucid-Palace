"use strict";
function displayFormData(){
	var queryString = location.search;
	queryString = queryString.substring(1,queryString.length-1);
	queryString = decodeURIComponent(queryString);
	queryString = queryString.replace(/\+/g," ");
	queryString = queryString.replace(/\=/g,": ");
	var formData = queryString.split(/[&:]/);
	var monthsArr=[	"January", "February", "March", "April", "May", "June", "July", 
					"August", "September","October", "November", "December"];		
	for(var i =0; i<formData.length;i++){
		/*
			NOTE: I printed the labels in all upper case because I did not want to go and 
				  rename all the tags in both the html and js files. some of them are named like
				  card number others like Room Type. So I just decided to have them all as uppercase.
		*/
		switch(formData[i].toLowerCase()){
			case "contact name":
				$("article").append("<h2 class='heading'>Guest Information</h2>");
				$("article").append("<span class='lbl'>"+formData[i].toUpperCase()+"</span>: ");
				$("article").append("<span class='vals'>"+formData[i+1]+" "+formData[i+3]+"</span><br> ");
				i+=3;
				continue;
			case "mobile phone number":
				$("article").append("<span class='lbl'>"+formData[i].toUpperCase()+"</span>: ");
				var phone = formData[i+1];
				phone = "(" + phone.substring(1,4) + ") " +
						phone.substring(4,7) + " - " +
						phone.substring(7,12);
				$("article").append("<span class='vals'>"+phone+"</span><br> ");
				i+=1;
				continue;
			case "email address":
				$("article").append("<span class='lbl'>"+formData[i].toUpperCase()+"</span>: ");
				$("article").append("<span class='vals'>"+formData[i+1]+"</span><br> ");
				i+=3;
				continue;
			case "room type":
				//only decrement room count when reached confirmation
				//people might start reservation and then cancel/change their minds
				var numAvailRooms;
				switch(formData[i+1]){
					case " Interconnecting":
						numAvailRooms = parseInt(localStorage.getItem("Interconnecting"));
						numAvailRooms--;
						localStorage.setItem("Interconnecting",numAvailRooms);
						alert(numAvailRooms);
						alert(localStorage.getItem("Interconnecting"));
						break;
					case " Duplex":
						numAvailRooms = parseInt(localStorage.getItem("Duplex"));
						numAvailRooms--;
						localStorage.setItem("Duplex",numAvailRooms);
						break;
					case " Lanai":
						numAvailRooms = parseInt(localStorage.getItem("Lanai"));
						numAvailRooms--;
						localStorage.setItem("Lanai",numAvailRooms);
						break;
					case " Suite":
						numAvailRooms = parseInt(localStorage.getItem("Suite"));
						numAvailRooms--;
						localStorage.setItem("Suite",numAvailRooms);
						break;
					case " King":
						numAvailRooms = parseInt(localStorage.getItem("King"));
						numAvailRooms--;
						localStorage.setItem("King",numAvailRooms);
						break;
				}
				$("article").append("<h2 class='heading'>Room Information</h2>");
				$("article").append("<span class='lbl'>"+formData[i].toUpperCase()+"</span>: ");
				break;
			case "date":
				$("article").append("<span class='lbl'>DURATION OF STAY</span>: ");
				$("article").append("<span class='vals'>"+"From " + formData[i+1] + " until " + formData[i+3] + "</span><br/>");
				i+=3;
				break;
			case "card type":
				$("article").append("<h2 class='heading'>Payment Information</h2>");
				$("article").append("<span class='lbl'>"+formData[i].toUpperCase()+"</span>: ");
				break;
			case "card number":
				var cnum = formData[i+1];
				cnum = cnum.substring(0,5) + " " +
					   cnum.substring(5,9) + " " +
					   cnum.substring(9,13) + " " +
					   cnum.substring(13);
				$("article").append("<span class='lbl'>"+formData[i].toUpperCase()+"</span>: ");
				$("article").append("<span class='vals'>"+cnum+"</span><br/>");
				i=formData.length;	//exit for loop because do not need to display exp date
				break;
			//all other name-value pairs from the form that do not need special actions
			default:
				if(i % 2 == 0)
					$("article").append("<span class='lbl'>"+formData[i].toUpperCase()+"</span>: ");
				else
					$("article").append("<span class='vals'>"+formData[i]+"</span><br> ");
				break;
		}
	}
	/*
		CHANGE CSS HERE FOR THE OUTPUT!
			I put classes for all the outputs so you don't need to change the code just css)
	*/
	//Headings
	$(".heading").css("background-color","purple"); // This is just a demonstration. Feel free to change Ostap)
	
	//Labels
	$(".lbl").css("background-color","yellow");	// This is just a demonstration. Feel free to change Ostap)
	$(".lbl").css("fontWeight","bold");	// This is just a demonstration. Feel free to change Ostap)
	$(".lbl").css("textDecoration","underline");	// This is just a demonstration. Feel free to change Ostap)
	
	//Values
	$(".vals").css("fontStyle","italic"); // This is just a demonstration. Feel free to change Ostap)
}
$("body").load(displayFormData());